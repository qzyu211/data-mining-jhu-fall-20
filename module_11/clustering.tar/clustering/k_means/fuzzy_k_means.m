function [mu_,P,no_iterations] = fuzzy_k_means(x,mu_0,b,P_0)
% function [mu_,P,no_iterations] = fuzzy_k_means(x,mu_0,b,P_0)
%
% M. Weisman

if nargin < 1 || isempty(x)
  x=[-1.0 -0.9 -0.8 .20 .40 .75;  -.10 .10 -.20  .05 .30 .40 ];
  disp('No input data given!');
end
if nargin < 2 || isempty(mu_0)
  mu_0 = [-.1 0 .3; 1 .5 -.2];
  disp('No initial means given!');
end
if nargin < 3 || isempty(b)
  b=2;
  disp('Fuzzy k-means with b=2');
end

[d1,k] = size(mu_0);
[d2,n] = size(x);
if d1==d2
  d = d1;
else
  error('dimensions of x and mu_0 must agree!');
end
if nargin <4 || isempty(P_0)
  P_0 = ones(k,n) ./k;
end

mu_=mu_0;
P = P_0;
delta_ = 1e3;
delta_P = 1e3;
epsilon_ = 1e-10; 
epsilon_P = .001;
iota_ = 1e-6;
if b<1.05
  iota_ = 1e-3;
end
no_iterations=0;
q=zeros(k,n);

while ((delta_ > epsilon_) & (delta_P > epsilon_P)) % 'and' to
                                                    % avoid cycling
  no_iterations = no_iterations+1;
  mu_old = mu_;
  P_old = P;
  for j = k:-1:1
    mu_array = repmat(mu_(:,j),[1,n]);
    if d == 1
      q(j,:) = (x-mu_array).*(x-mu_array);
    else
      q(j,:) = sum((x-mu_array).*(x-mu_array));
    end
  end
  q = max(q ,iota_);        % we are taking reciprocal of q, 
                            % ought to not be zero (or too large)
  P = (1./q).^(1./(b-1));   
  index=find(0==(ones(1,k)*P));  % if q too large, a column of P can be all zeros!
  for z=index
      P(:,z)=ones(3,1);
  end
  P = normalize_P(P);
  mu_ =  x * (P.^b)';
  phi_= repmat(sum((P.^b)'),[d,1]);
  mu_ = mu_ ./ phi_;
  delta_  = sum(dot(mu_ - mu_old, mu_-mu_old));
  delta_P = sum(dot(P - P_old, P-P_old));
end

