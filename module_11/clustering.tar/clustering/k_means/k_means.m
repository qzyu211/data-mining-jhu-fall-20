function [mu_,b,no_iterations] = k_means(x,mu_0,max_no_iterations,verbose)
% function [mu_,b,no_iterations] = k_means(x,mu_0,max_no_iterations,verbose)
%
% M. Weisman

if nargin < 1 || isempty(x)
  x=[-1.0 -.90 -.80 .20 .40 .75; -.10 .10 -.20  .05 .30 .40 ];
  disp('No input data given!');
end
if nargin < 2 || isempty(mu_0)
  mu_0 = [-.1 0 .3; -.1 0 .3];
  disp('No initial means given!');
end
if nargin < 4 || isempty(verbose)
  verbose=0;
end
if nargin < 3 || isempty(max_no_iterations)
  max_no_iterations=200;
  if verbose
    disp('Setting Maximum number of iterations to 200.');
  end
end

[d1,k] = size(mu_0);
[d2,n] = size(x);
if d1==d2
  d = d1;
else
  error('dimensions of x and mu_0 must agree!');
end
mu_=mu_0;
delta_ = 1e3;
epsilon_ = .025;
no_iterations=0;
while delta_ > epsilon_
  if no_iterations==max_no_iterations
    if verbose
      disp(' ');
      disp('Within k-means algorithm:');
      disp('Maximum number of iterations reached before convergence.');
    end
    return;
  else
    no_iterations = no_iterations+1;
    mu_old = mu_;
    for j = k:-1:1
      mu_array = repmat(mu_(:,j),[1,n]);
      if d == 1
        q(j,:) = (x-mu_array).*(x-mu_array);
      else
        q(j,:) = sum((x-mu_array).*(x-mu_array));
      end
    end
    b=(q==repmat(min(q),[k,1]));
    n_j = repmat(sum(b'),[n,1])';
    mu_ =  x * (b./n_j)';
    delta_ = sum(dot(mu_ - mu_old, mu_-mu_old));
  end
end
