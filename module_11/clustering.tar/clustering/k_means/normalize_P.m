function P_out = normalize_P(P_in)
iota_ = 1e-12;
[k,n] = size(P_in);
gamma_ = repmat(sum(P_in),[k,1]);
P_out = P_in ./ gamma_;