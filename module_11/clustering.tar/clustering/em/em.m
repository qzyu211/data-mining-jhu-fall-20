function [m,S,h,no_iterations] = em(x,mu_0)
% function [m,S,h,no_iterations] = em(x,mu_0)
%
% M. Weisman
%
% Expectation-Maximization algorithm
% for Gaussian mixture model

if nargin < 1 || isempty(x)
  x=randn(2,100);
  disp('No input data given!');
end
if nargin < 2 || isempty(mu_0)
  mu_0 = [-1 0 1; 0 0 0];
  disp('No initial means given!');
end

on_error = 'dimensions of x and mu_0 must agree!';
[d,k,n] = check_dimensions_of_x_and_mu(x,mu_0,on_error);

if k==1
  b = ones(1,n);
else
  [mu_0,b,no_k_means_iterations] = k_means(x,mu_0,3); % initial EM algorithm with k_means
end
S = calculate_S(x,mu_0,b');                           % initialize S
pi_ = sum(b')./n;                                     % set priors
m = mu_0;

delta_ = 1e3;
epsilon_ = 1e-3;
no_iterations=0;
while delta_ > epsilon_
  no_iterations = no_iterations+1;
  m_prev = m;
  S_prev = S;
%----------------------------------------------------------------------
% Expectation (E-Step)
%----------------------------------------------------------------------
  h = calculate_h(pi_,S,x,m);
%----------------------------------------------------------------------
% Maximization (M-Step)
%----------------------------------------------------------------------
  m = calculate_m(h,x);
  S = calculate_S(x,m,h);
%----------------------------------------------------------------------
  [alpha_,beta_,gamma_] = size(S);
  q = zeros(alpha_,beta_);
  for p = k:-1:1
    q = q + S(:,:,p) - S_prev(:,:,p);
  end
  delta_1 = sum(dot(m - m_prev, m-m_prev));
  delta_2 = trace(q*q);
  delta_ = delta_1 + delta_2;
end

