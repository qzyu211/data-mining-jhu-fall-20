function h = calculate_h(pi_,S,x,m)
distance = calculate_distance(x,m,S);
[a,k] = size(distance);
for j = k:-1:1,
  w(j) = pi_(j) .* det(S(:,:,j)).^(-1./2);
end
p = repmat(w,[a,1]);
q = p .* exp(-distance ./2);
if k==1
  r = q;
else
  r = sum(q')';
end
s = repmat(r,[1,k]);
h = q ./ s;
