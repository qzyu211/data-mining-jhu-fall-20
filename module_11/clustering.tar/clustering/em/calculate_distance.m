function distance = calculate_distance(x,mu_,S)
% function distance = calculate_distance(x,mu_,S)
%
% M. Weisman
%
% Calculates the Mahalanobis distance between data points {x}
% and means {mu_} with respect to covariances S(:,:,j)

on_error = 'dimensions of x and mu_ must agree!';
[d,k,n] = check_dimensions_of_x_and_mu(x,mu_,on_error);

for j = k:-1:1,
    mu_array = repmat(mu_(:,j),[1,n]);
    for m = n:-1:1,
      q = x(:,m) - mu_array(:,m);
      distance(m,j) = q' * (S(:,:,j) \ q);
    end
end


 
