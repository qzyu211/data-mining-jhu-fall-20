function [d,k,n] = check_dimensions_of_x_and_h(x,h,on_error);

[n1,k] = size(h);
[d,n2] = size(x);
if n1==n2
  n = n1;
else
  error(on_error);
end
