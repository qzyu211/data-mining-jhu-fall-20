function m = calculate_m(h,x)

on_error = 'dimensions of x and h must correspond!';
[d,k,n] = check_dimensions_of_x_and_h(x,h,on_error);

for j = k:-1:1
  q = repmat(h(:,j)',[d,1]);
  r = q .* x;
  m(:,j) = sum(r') ./ repmat(sum(h(:,j)),[1,d]);
end

