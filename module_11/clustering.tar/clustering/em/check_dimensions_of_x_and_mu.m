function [d,k,n] = check_dimensions_of_x_and_mu(x,mu_0,on_error);

[d1,k] = size(mu_0);
[d2,n] = size(x);
if d1==d2
  d = d1;
else
  error(on_error);
end
