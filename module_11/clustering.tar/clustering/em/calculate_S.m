function S = calculate_S(x,mu_,h)

on_error = 'dimensions of x and mu_ must agree!';
[d,k,n] = check_dimensions_of_x_and_mu(x,mu_,on_error);

for j = k:-1:1
  mu_array = repmat(mu_(:,j),[1,n]);
  h_array = repmat(h(:,j)',[d,1]);
  q = (h_array .* (x-mu_array))*(x-mu_array)';
  r = sum(h(:,j)');
  S(:,:,j) = q ./ r;
 end
 